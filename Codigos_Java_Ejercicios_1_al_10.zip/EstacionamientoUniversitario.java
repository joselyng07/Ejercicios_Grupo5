import java.util.Scanner;

public class EstacionamientoUniversitario {
     public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);

         int motocicletas = 0, automoviles = 0, camionetas = 0;
         int totalVehiculos = 0;
         double totalRecaudado = 0;
         String continuar;

         do {
                int tipo;
                do {
                     System.out.println("\n1. Motocicleta");
                     System.out.println("2. Automóvil");
                     System.out.println("3. Camioneta");
                     System.out.print("Seleccione el tipo: ");
                     while (!sc.hasNextInt()) {
                         System.out.print("Ingrese un número válido: ");
                         sc.next();
                     }
                     tipo = sc.nextInt();
                     if (tipo < 1 || tipo > 3) {
                         System.out.println("Tipo no válido.");
                     }
                } while (tipo < 1 || tipo > 3);

                double tarifa = 0;

                switch (tipo) {
                    case 1:
                        tarifa = 0.50;
                        motocicletas++;
                        break;
                    case 2:
                        tarifa = 1.00;
                        automoviles++;
                        break;
                    case 3:
                        tarifa = 1.50;
                        camionetas++;
                        break;
                }

                double horas;
                do {
                     System.out.print("Horas estacionado: ");
                     while (!sc.hasNextDouble()) {
                         System.out.print("Ingrese un número válido: ");
                         sc.next();
                     }
                     horas = sc.nextDouble();
                     if (horas <= 0) {

                         System.out.println("Las horas deben ser mayores que cero.");
                     }
                 } while (horas <= 0);

                 double pago = horas * tarifa;
                 totalVehiculos++;
                 totalRecaudado += pago;

                 do {
                     System.out.print("¿Desea registrar otro vehículo? (S/N): ");
                     continuar = sc.next().toUpperCase();
                 } while (!continuar.equals("S") && !continuar.equals("N"));

             } while (continuar.equals("S"));

             double promedio = totalRecaudado / totalVehiculos;

             System.out.println("\n===== REPORTE =====");
             System.out.println("Motocicletas: " + motocicletas);
             System.out.println("Automóviles: " + automoviles);
             System.out.println("Camionetas: " + camionetas);
             System.out.println("Total vehículos: " + totalVehiculos);
             System.out.printf("Total recaudado: $%.2f%n", totalRecaudado);
             System.out.printf("Promedio pagado: $%.2f%n", promedio);
             System.out.println("===================");
             sc.close();
         }
    }
