import java.util.Scanner;

public class Ejercicio9 {
       public static void main(String[] args) {
           Scanner sc = new Scanner(System.in);

           int n;
           do {
                System.out.print("Cantidad de estudiantes: ");

    n = sc.nextInt();
    if (n <= 0) System.out.println("Debe ser mayor que 0.");
} while (n <= 0);

int[] edad = new int[n];
int[] semestre = new int[n];
double[] horas = new double[n];

int sumaEdad = 0;
double sumaHoras = 0;
int menor2 = 0;
double mayorHoras = -1;
int estudianteMayor = 0;

for (int i = 0; i < n; i++) {
    do {
         System.out.print("Edad del estudiante " + (i + 1) + ": ");
         edad[i] = sc.nextInt();
    } while (edad[i] < 16 || edad[i] > 80);

    do {
        System.out.print("Semestre (1-10): ");
        semestre[i] = sc.nextInt();
    } while (semestre[i] < 1 || semestre[i] > 10);

    do {
        System.out.print("Horas de estudio por día (0-24): ");
        horas[i] = sc.nextDouble();
    } while (horas[i] < 0 || horas[i] > 24);

    sumaEdad += edad[i];
    sumaHoras += horas[i];

    if (horas[i] > mayorHoras) {
        mayorHoras = horas[i];
        estudianteMayor = i + 1;
    }

    if (horas[i] < 2) {
        menor2++;
    }
}

System.out.println("\n--- ESTADISTICAS ---");
System.out.printf("Edad promedio: %.2f%n", (double) sumaEdad / n);
System.out.printf("Horas promedio: %.2f%n", sumaHoras / n);
System.out.println("Estudiante con mayor cantidad de horas: "
        + estudianteMayor + " (" + mayorHoras + " h)");
System.out.println("Estudiantes con menos de 2 horas: " + menor2);

System.out.println("\nEstudiantes por semestre:");
// Ciclos anidados
for (int s = 1; s <= 10; s++) {
    int contador = 0;
    for (int i = 0; i < n; i++) {
        if (semestre[i] == s) {
            contador++;
        }
    }
    System.out.println("Semestre " + s + ": " + contador);
}

sc.close();

        }
   }
