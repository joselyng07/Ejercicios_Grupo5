import java.util.Scanner;

public class Ejercicio4Cajero {

public static void main(String[] args) {

Scanner sc = new Scanner(System.in);

double saldo = 500;

   double monto;

double totalDepositado = 0;

   double totalRetirado = 0;

int depositosRealizados = 0;

   int retirosRealizados = 0;

int opcion;

do {

System.out.println("\n========================");

     System.out.println(" CAJERO AUTOMATICO");

     System.out.println("========================");

     System.out.println("1. Consultar saldo");

     System.out.println("2. Depositar");

     System.out.println("3. Retirar");

     System.out.println("4. Mostrar movimientos");

     System.out.println("5. Salir");

System.out.print("Seleccione una opcion: ");

opcion = sc.nextInt();

switch (opcion) {

case 1:

System.out.printf("Saldo disponible: $%.2f%n", saldo);

break;

case 2:

System.out.print("Ingrese el valor a depositar: ");

   monto = sc.nextDouble();

if (monto < 0) {

System.out.println(

          "No se permiten depositos negativos."

     );

} else {

saldo += monto;

     depositosRealizados++;

totalDepositado += monto;

System.out.println(

          "Deposito realizado correctamente."

     );

 }

break;

case 3:

System.out.print("Ingrese el valor a retirar: ");

 monto = sc.nextDouble();

if (monto < 0) {

System.out.println(

          "No se permiten retiros negativos."

     );

} else if (monto > saldo) {

System.out.println(

          "No puede retirar mas dinero del disponible."

     );

 } else {

saldo -= monto;

retirosRealizados++;

totalRetirado += monto;

System.out.println(

           "Retiro realizado correctamente."

      );

 }

break;

case 4:

System.out.println("\n--- MOVIMIENTOS ---");

System.out.println(

      "Depositos realizados: "

      + depositosRealizados

 );

System.out.println(

      "Retiros realizados: "

      + retirosRealizados

 );

System.out.printf(

      "Total depositado: $%.2f%n",

      totalDepositado

 );

System.out.printf(

      "Total retirado: $%.2f%n",

      totalRetirado

 );

System.out.printf(

      "Saldo actual: $%.2f%n",

      saldo

 );

break;

case 5:

System.out.println(

      "Saliendo del cajero..."

 );

break;

         default:

System.out.println(

               "Opcion inexistente."

          );

     }

} while (opcion != 5);

System.out.println("\n===== RESUMEN FINAL =====");

System.out.println(

     "Depositos realizados: "

     + depositosRealizados

);

System.out.println(

     "Retiros realizados: "

     + retirosRealizados

);

System.out.printf(

     "Total depositado: $%.2f%n",

     totalDepositado

);

        System.out.printf(

             "Total retirado: $%.2f%n",

             totalRetirado

        );

System.out.printf(

             "Saldo final: $%.2f%n",

             saldo

        );

sc.close();

    }

}
