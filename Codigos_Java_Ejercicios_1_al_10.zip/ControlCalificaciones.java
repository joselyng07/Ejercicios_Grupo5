import java.util.Scanner;

public class ControlCalificaciones {

public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

int n;
            int aprobados = 0;
            int reprobados = 0;
            double suma = 0;
            double notaAlta = Double.NEGATIVE_INFINITY;
            double notaBaja = Double.POSITIVE_INFINITY;

// Validar número de estudiantes con 'while'
            System.out.print("Ingrese el número de estudiantes (N > 0): ");
            n = scanner.nextInt();

while (n <= 0) {

https://utaedu-my.sharepoint.com/personal/jr_caiza_uta_edu_ec/_layouts/15/Doc.aspx?sourcedoc={0f346019-d1e7-4df5-86b4-f2a8eefd2323}&ac…   3/5

23/9/26, 8:19 a.m.                                                                                            OneNote
                    System.out.print("Error: El número de estudiantes debe ser mayor que cero. Intente de nuevo:
        ");
                    n = scanner.nextInt();
                }

// Procesar calificaciones con 'for'
                for (int i = 1; i <= n; i++) {
                    System.out.print("Ingrese la calificación del estudiante " + i + " (0 a 10): ");
                    double nota = scanner.nextDouble();

// Validar rango de la calificación con 'while'
                    while (nota < 0 || nota > 10) {
                        System.out.print("Error: La calificación debe estar entre 0 y 10. Intente de nuevo: ");
                        nota = scanner.nextDouble();
                    }

// Acumular y contar
                    suma += nota;

if (nota >= 7.0) {
                        aprobados++;
                    } else {
                        reprobados++;
                    }

// Actualizar nota más alta y más baja
                    if (nota > notaAlta) {
                        notaAlta = nota;
                    }
                    if (nota < notaBaja) {
                        notaBaja = nota;
                    }
                }

// Calcular promedio general
                double promedio = suma / n;

// Mostrar resultados
                System.out.println("\n--- RESULTADOS ---");
                System.out.println("Número de estudiantes: " + n);
                System.out.printf("Suma de calificaciones: %.2f\n", suma);
                System.out.printf("Promedio general: %.2f\n", promedio);
                System.out.println("Cantidad de aprobados: " + aprobados);
                System.out.println("Cantidad de reprobados: " + reprobados);
                System.out.printf("Nota más alta: %.2f\n", notaAlta);
                System.out.printf("Nota más baja: %.2f\n", notaBaja);

scanner.close();
            }
        }
